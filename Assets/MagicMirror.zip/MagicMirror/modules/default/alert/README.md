# Module: Alert

The alert module is one of the default modules of the MagicMirror². This module displays notifications from other modules.

For configuration options, please check the [MagicMirror² documentation](https://docs.magicmirror.builders/modules/alert.html).
